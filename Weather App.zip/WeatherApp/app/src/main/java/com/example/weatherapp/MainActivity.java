package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.channels.AsynchronousChannelGroup;
import java.util.ArrayList;
import java.util.List;

//1fdd6352f06fff0a78dcb07cefc999bb
//http://api.openweathermap.org/geo/1.0/zip?zip=08812,us&appid=1fdd6352f06fff0a78dcb07cefc999bb
//image, temperature, short description, and the time for each weather report.
//https://api.openweathermap.org/data/2.5/onecall?lat=40.3825&lon=-74.5111&exclude=current,minutely,daily,alerts&units=metric&appid=1fdd6352f06fff0a78dcb07cefc999bb
public class MainActivity extends AppCompatActivity {
private TextInputEditText zipCodeEt;
private ListView listView;
private TextView cityInfoTv;
private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        zipCodeEt = findViewById(R.id.tieZipCode);
        listView = findViewById(R.id.weatherList);
        cityInfoTv = findViewById(R.id.cityInfoTv);

        Button runButton = findViewById(R.id.runButton);
        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Validate the zipcode
                String zipCode = zipCodeEt.getText().toString();
                if(!zipCode.trim().isEmpty()){
                    //Call GeoCoding Api
                    callGeoCodingApi(zipCode);
                }else{
                    Toast.makeText(MainActivity.this, getString(R.string.enter_zip_code), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void callGeoCodingApi(String zipCode) {
        String geoCodeUrl = "http://api.openweathermap.org/geo/1.0/zip?zip="+zipCode+",us&appid=1fdd6352f06fff0a78dcb07cefc999bb";
        new HttpAsyncTask(this,1).execute(geoCodeUrl);
    }


    class HttpAsyncTask extends AsyncTask<String,Void, String>{
        private MainActivity activity;
        private int flag = 0;

        public HttpAsyncTask(MainActivity activity, int flag) {
            this.activity = activity;
            this.flag = flag;
        }

        @Override
        protected String doInBackground(String... data) {
            String output = "";
            try {
                URL url = new URL(data[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                int respCode = conn.getResponseCode();
                if(respCode == HttpURLConnection.HTTP_OK){
                  BufferedReader is = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                  String line;
                  StringBuilder response = new StringBuilder();
                  while ((line = is.readLine())!=null){
                      response.append(line);
                  }
                  is.close();
                  output = response.toString();
                }else{
                    Log.d(TAG,"Error occurred : -"+respCode);
                }
            } catch (IOException e) {
                Log.d(TAG,"Some exception : -"+e.getMessage());
            }
            return output;
        }

        @Override
        protected void onPostExecute(String response) {
           if(!response.isEmpty()){
               Log.d(TAG,response);
               try {
                   if(flag ==1){
                       JSONObject json = new JSONObject(response);
                       double lat = json.getDouble("lat");
                       double lng = json.getDouble("lon");
                       String place = json.getString("name") +", "+json.getString("country");
                       cityInfoTv.setText(String.format(place+", %f, %f",lat,lng));
                       callOneCallApi(lat,lng);
                   }
                   if(flag ==2){
                     //"hourly":[{"dt":1643151600,"temp":34.29,"feels_like":27.68,"pressure":1018,"humidity":60,"dew_point":23.02,"uvi":0,"clouds":58,"visibility":10000,"wind_speed":7.92,"wind_deg":302,"wind_gust":19.19,"weather":[{"id":803,"main":"Clouds","description":"broken clouds","icon":"04n"}],"pop":0},
                      JSONObject json = new JSONObject(response);
                       JSONArray hourlyArray = json.getJSONArray("hourly");
                       List<Weather> weatherList = new ArrayList<>();
                       for(int i =0; i<4;i++){
                          JSONObject jsonHour = hourlyArray.getJSONObject(i);
                          String time = jsonHour.getString("dt");
                          double temp = jsonHour.getDouble("temp");

                          JSONArray weatherArray = jsonHour.getJSONArray("weather");
                          JSONObject jsonWeather = weatherArray.getJSONObject(0);

                          String imageIcon = jsonWeather.getString("icon");
                          String description = jsonWeather.getString("description");

                          weatherList.add(new Weather(imageIcon,temp,time,description));
                       }

                       populateWeatherList(weatherList);
                   }
               } catch (JSONException e) {
                   Log.d(TAG,"Error : -"+e.getMessage());
               }
           }else {
               Toast.makeText(MainActivity.this, "Something went wrong, please try later!", Toast.LENGTH_SHORT).show();
           }
        }
    }

    private void populateWeatherList(List<Weather> weatherList) {
        WeatherAdapter adapter =new WeatherAdapter(this,R.layout.list_item_weather,weatherList);
        listView.setAdapter(adapter);
    }

    private void callOneCallApi(double lat, double lng) {
        String oneCallUrl = "https://api.openweathermap.org/data/2.5/onecall?lat="+lat+"&lon="+lng+"&exclude=current,minutely,daily,alerts&units=imperial&appid=1fdd6352f06fff0a78dcb07cefc999bb";
        new HttpAsyncTask(this,2).execute(oneCallUrl);
    }
}