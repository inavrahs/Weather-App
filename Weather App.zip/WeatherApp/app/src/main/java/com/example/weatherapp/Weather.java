package com.example.weatherapp;

public class Weather {
    private String imageUrl;
    private double temp;
    private String time;
    private String description;

    public Weather(String imageUrl, double temp, String time, String description) {
        this.imageUrl = imageUrl;
        this.temp = temp;
        this.time = time;
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public double getTemp() {
        return temp;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Weather{" +
                "imageUrl='" + imageUrl + '\'' +
                ", temp=" + temp +
                ", time='" + time + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
