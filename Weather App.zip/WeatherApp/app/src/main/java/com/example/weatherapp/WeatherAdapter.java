package com.example.weatherapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class WeatherAdapter extends ArrayAdapter<Weather> {

    private List<Weather> weatherList;

    public WeatherAdapter(@NonNull Context context, int resource, @NonNull List<Weather> weatherList) {
        super(context, resource, weatherList);
        this.weatherList = weatherList;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        Weather weather = weatherList.get(position);
        View view = convertView;
        if (view == null)
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_weather, parent, false);

        TextView tempTv = view.findViewById(R.id.tempTv);
        TextView timeTv = view.findViewById(R.id.timeTv);
        TextView descTv = view.findViewById(R.id.shortDescTv);
        ImageView imageView = view.findViewById(R.id.weatherIconImv);

        //http://openweathermap.org/img/wn/10d@2x.png
        String imageUrl = String.format(Locale.ENGLISH, "http://openweathermap.org/img/wn/%s.png", weather.getImageUrl());

        Glide.with(getContext()).load(imageUrl).into(imageView);

        String tempString = String.format(Locale.US,"Temp : %.2f",weather.getTemp());
        tempTv.setText(tempString);



        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Long.parseLong(weather.getTime())*1000);
        String formattedTime = new SimpleDateFormat("HH:mm", Locale.US).format(calendar.getTime());
        timeTv.setText(String.format(Locale.getDefault(),"Time : %s",formattedTime));



        descTv.setText(weather.getDescription());


        return view;
    }
}
